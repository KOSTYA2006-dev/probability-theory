
function test(){
alert('hi')
}