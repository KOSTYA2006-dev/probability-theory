from django.urls import path

from . import views
# from .views import MyprojectLoginView

urlpatterns = [

    path('register/', views.register, name = 'register'),
    # path('login/', MyprojectLoginView.as_view, name = 'MyprojectLoginView')

]