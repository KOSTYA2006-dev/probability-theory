# Подключаем компонент для работы с формой
from django import forms
# Подключаем компонент UserCreationForm
from django.contrib.auth.forms import UserCreationForm
# Подключаем модель User

from django.contrib.auth.models import User


class UserRegistrationForm(UserCreationForm):
    username = forms.CharField(label='username', widget=forms.TextInput(attrs={'class': 'intput-r'}))
    email = forms.EmailField(label='Email', widget=forms.EmailInput(attrs={'class': 'intput-r'}))
    password1 = forms.CharField(label='password', widget=forms.PasswordInput(attrs={'class': 'intput-r'}))

    password2 = forms.CharField(label='Repeat password', widget=forms.PasswordInput(attrs={'class': 'intput-r'}))

    class Meta:
        model = User
        fields = ('username', 'email', 'password1', 'password2')

    def clean_password2(self):
        cd = self.cleaned_data
        if cd['password1'] != cd['password2']:
            raise forms.ValidationError('Passwords don\'t match.')
        return cd['password2']


class AuthUserForm(UserCreationForm, forms.ModelForm):
    username = forms.CharField(label='username', widget=forms.TextInput(attrs={'class': 'intput-r'}))
    password = forms.CharField(label='password', widget=forms.PasswordInput(attrs={'class': 'intput-r'}))

    class Meta:
        model = User
        fields = ('username', 'password')

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field in self.fields:
            self.fields[field].widget.attrs['class'] = 'form-control'
