# Подключение для рендера
from django.shortcuts import render, redirect
from django.db import models
# Подключение стандартной формы для регистрации
from django.contrib.auth.forms import UserCreationForm
# from .models import Article, Comment
from django.contrib.auth.models import User

from django.urls import reverse, reverse_lazy
from .forms import UserRegistrationForm, AuthUserForm
from django.contrib.auth.views import LoginView


def register(request):
    if request.method == 'POST':
        user_form = UserRegistrationForm(request.POST)
        if user_form.is_valid():
            # Create a new user object but avoid saving it yet
            new_user = user_form.save(commit=False)
            # Set the chosen password
            new_user.set_password(user_form.cleaned_data['password1'])
            # Save the User object
            new_user.save()
            return redirect('/')
    else:
        user_form = UserRegistrationForm()
    return render(request, 'articles/signup.html', {'user_form': user_form})


class LoginView(LoginView):
    template_name = 'login.html'
    form_class = AuthUserForm
    success_url = reverse_lazy('edit_page')


    def get_success_url(self):
        return self.success_url