from django.http import HttpResponse
from django.shortcuts import render
from .models import Article, Comment


def index(request):
    public_articles = Article.objects.order_by('-id')

    return render(request, 'articles/home.html', {'public_articles': public_articles})

def teoriya(request):

    return render(request, 'articles/teoriya.html')