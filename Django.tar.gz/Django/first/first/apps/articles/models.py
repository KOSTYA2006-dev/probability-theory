from django.db import models


class Article(models.Model):
    artical_title = models.CharField('Название статьи', max_length=100)
    artical_text = models.TextField('Текст статьи')
    pud_date = models.DateTimeField('Дата публикации')


    def __str__(self):

        return self.artical_text


class Comment(models.Model):
    article = models.ForeignKey(Article, on_delete = models.CASCADE)
    comement_text = models.CharField('текст комментария', max_length=250)


class Image(models.Model):
    title = models.TextField()
    cover = models.ImageField(upload_to='images')

    def __str__(self):
        return self.title

