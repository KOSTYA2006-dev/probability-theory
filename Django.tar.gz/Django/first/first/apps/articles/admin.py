from django.contrib import admin
from .models import Image
from .models import Article, Comment
from django.contrib.auth.admin import UserAdmin
from django.db import models
from .models import Image

admin.site.register(Image)
admin.site.register(Article)

admin.site.register(Comment)

