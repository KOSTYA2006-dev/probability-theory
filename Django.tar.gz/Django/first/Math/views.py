from django.shortcuts import render

from django.http import HttpResponse
from django.shortcuts import render
from .models import *
from .models import ArticleMath


def Math(request):
    articlesmath = ArticleMath.objects.order_by('-id')

    return render(request, 'articlesmath/math.html', {'public_articles': articlesmath})



# def teoriya(request):
#
#     return render(request, 'articles/teoriya.html')