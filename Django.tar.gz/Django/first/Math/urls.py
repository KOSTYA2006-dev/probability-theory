from django.urls import path

from . import views
# from .views import MyprojectLoginView

urlpatterns = [

    path('math/', views.Math, name = 'math'),
    # path('login/', MyprojectLoginView.as_view, name = 'MyprojectLoginView')

]