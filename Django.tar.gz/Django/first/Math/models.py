from django.db import models

# Create your models here.
from django.db import models


class ArticleMath(models.Model):
    articalmath_title = models.CharField('Название статьи', max_length=100)
    articalmath_text = models.TextField('Текст статьи')
    pud_date = models.DateTimeField('Дата публикации')
    title = models.TextField()
    cover = models.ImageField(upload_to='images')


    def __str__(self):

        return self.articalmath_text






