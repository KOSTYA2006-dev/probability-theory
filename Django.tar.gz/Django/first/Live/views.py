from django.shortcuts import render
from .models import ArticleLives


def Live(request):

    articleslive = ArticleLives.objects.order_by('-id')

    return render(request, 'articleslive/live.html', {'public_articles': articleslive})