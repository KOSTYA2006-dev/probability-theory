from django.db import models

# Create your models here.
from django.db import models


class ArticleLives(models.Model):
    articallive_title = models.CharField('Название статьи', max_length=100)
    articallive_text = models.TextField('Текст статьи')
    pud_date = models.DateTimeField('Дата публикации')
    title = models.TextField()
    cover = models.ImageField(upload_to='images')

    def __str__(self):

        return self.articallive_text
